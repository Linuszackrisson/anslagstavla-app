const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.handler = async (event) => {
  console.log('deleteMessage function started', JSON.stringify(event, null, 2));

  const { id } = event.pathParameters;
  console.log('Attempting to delete message with id:', id);

  const params = {
    TableName: process.env.DYNAMODB_TABLE,
    Key: { id },
    ReturnValues: 'ALL_OLD'
  };

  console.log('DynamoDB delete params:', JSON.stringify(params, null, 2));

  try {
    console.log('Calling DynamoDB delete');
    const result = await dynamoDb.delete(params).promise();
    console.log('DynamoDB delete result:', JSON.stringify(result, null, 2));

    if (!result.Attributes) {
      console.log('No item found to delete');
      return {
        statusCode: 404,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Credentials': true,
        },
        body: JSON.stringify({ error: 'Message not found' }),
      };
    }

    console.log('Message deleted successfully');
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
      },
      body: JSON.stringify({ message: 'Message deleted successfully', deletedItem: result.Attributes }),
    };
  } catch (error) {
    console.error('Error deleting message:', error);
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
      },
      body: JSON.stringify({ error: 'Could not delete the message', details: error.message, stack: error.stack }),
    };
  }
};
